import random
from torchvision.transforms import functional as F

class Compose(object):
    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, image, point_loc):
        for t in self.transforms:
            image = t(image, point_loc)
        return image

    def __repr__(self):
        format_string = self.__class__.__name__ + "("
        for t in self.transforms:
            format_string += "\n"
            format_string += "    {0}".format(t)
        format_string += "\n)"
        return format_string

class Resize(object):
    '''
        Resize the training diagram samples, resize the longest edge as max_size
    '''
    def __init__(self, max_size):
        self.max_size = max_size

    def get_size(self, image_size, point_loc):
        w, h = image_size
        if w < h:
            ow = int(w * self.max_size / h)
            oh = self.max_size
        else:
            ow = self.max_size
            oh = int(h * self.max_size / w)
        
        for item in point_loc:
            point_loc[item][0] = point_loc[item][0] * ow / w
            point_loc[item][1] = point_loc[item][1] * ow / w
                
        return (oh, ow)

    def __call__(self, image, point_loc): 
        size = self.get_size(image.size, point_loc)
        image = F.resize(image, size)
        return image

class CenterCrop(object):
    '''
        Crops the given image at the center.
    '''
    def __init__(self, size):
        self.size = size

    def __call__(self, image, point_loc):
        return F.center_crop(image, self.size)

class RBPad(object):
    '''
       pad the right and bottom sides of image 
    '''
    def __init__(self, max_size):
        self.max_size = max_size

    def __call__(self, image, point_loc):
        w, h = image.size
        right_side_add = max(0, self.max_size - w)
        bottom_side_add = max(0, self.max_size - h)
        return F.pad(image, [0, 0, right_side_add, bottom_side_add])

class RandomFlip(object):
    def __init__(self, prob=0.5):
        self.prob = prob

    def __call__(self, image, point_loc):
        if random.random() < self.prob:
            flip_method = random.choice([0,1,2])
            w, h = image.size
            if flip_method==0:
                image = F.hflip(image)
                for item in point_loc:
                    point_loc[item][0] = w+1-point_loc[item][0]
            elif flip_method==1:
                image = F.vflip(image)
                for item in point_loc:
                    point_loc[item][1] = h+1-point_loc[item][1]
            elif flip_method==2:
                image = F.vflip(F.hflip(image))
                for item in point_loc:
                    point_loc[item][0] = w+1-point_loc[item][0]
                    point_loc[item][1] = h+1-point_loc[item][1]
        return image

class ToTensor(object):
    def __call__(self, image, point_loc):
        return F.to_tensor(image)

class Normalize(object):
    def __init__(self, mean=[0.85,0.85,0.85], std=[0.3,0.3,0.3]):
        self.mean = mean
        self.std = std

    def __call__(self, image, point_loc):
        image = F.normalize(image, mean=self.mean, std=self.std)
        return image