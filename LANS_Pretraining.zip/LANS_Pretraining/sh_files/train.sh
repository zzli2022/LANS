python -m torch.distributed.launch \
    --nproc_per_node=8 \
    --master_port=$((RANDOM + 10000)) \
    start.py \
    --project_dropout 0.2 \
    --loss_ratio 0.8 \
    --lr 1e-5 \
    --dataset_dir /data/nas/lizhongzhi/data/LANS_DATA \
    --project_type 'cnn' \
    --similar_type 'cosine' \
    --max_epoch 5000 \
    --batch_size 1024 \
    --scheduler_step 500 1000 2000 3000 \
    --exp_id lr_5e-5_continue \
    --encoder_hidden_size 768 \
    --encoder_embedding_size 768 \
    --pretrain_head 12 \
    --pretrain_layer 12 \
    --warm_epoch 40 \
    --dump_path ./log/pretrain_base 