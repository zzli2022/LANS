import time
from utils import *

def train(args, epoch, train_loader, model, criterion, optimizer):

    batch_time = AverageMeter('Time', ':5.3f')
    data_time = AverageMeter('Data', ':5.3f')
    losses = AverageMeter('Loss', ':.4e')
    
    losses_mlm = AverageMeter('Loss_mlm', ':.4e')
    losses_img2text = AverageMeter('Loss_img2text', ':.4e')
    
    progress = ProgressMeter(len(train_loader), [batch_time, data_time, losses, losses_mlm, losses_img2text],
                             args, prefix="Epoch: [{}]".format(epoch))

    # switch to train mode
    model.train()
    end = time.time()
    # TODO (初步感觉温度系数也不是那么重要) 
    temperature = 0.2

    for i, (diagrams, text_dict, loc_labels) in enumerate(train_loader):
        '''
            text_dict = {'token', 'sect_tag', 'class_tag', 'len', 'labels'}
        '''
        # measure data loading time
        data_time.update(time.time() - end)
        # set cuda for input data
        diagrams = diagrams.cuda()
        loc_labels = loc_labels.cuda()
        set_cuda(text_dict)
        # compute output
        mlm_score, in_score = model(diagrams, text_dict, is_train=True)
        
        loss_mlm = criterion(mlm_score, text_dict['labels'])
        loss_img2text = criterion(in_score/temperature, loc_labels)
        # TODO (损失比例系数调整, 感觉mlm损失相对比较重要些)
        loss = args.loss_ratio*loss_mlm + (1-args.loss_ratio)*loss_img2text
        
        # update the loss
        torch.distributed.barrier()
        reduced_loss = reduce_mean(loss, args.nprocs)
        losses.update(reduced_loss.item(), len(text_dict['sect_tag']))
        
        reduced_loss_mlm = reduce_mean(loss_mlm, args.nprocs)
        losses_mlm.update(reduced_loss_mlm.item(), len(text_dict['sect_tag']))
        
        reduced_loss_img2text = reduce_mean(loss_img2text, args.nprocs)
        losses_img2text.update(reduced_loss_img2text.item(), len(text_dict['sect_tag']))
        
        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()
        if i % args.print_freq == 0:
            progress.display(i, lr = optimizer.state_dict()['param_groups'][0]['lr'])

    return losses.avg
