import torch
import torch.nn as nn
from model.encoder import TransformerEncoder
from utils.utils import *
import numpy as np
from einops.layers.torch import Rearrange
from model.backbone import get_visual_backbone

class Network(nn.Module):
    
    def __init__(self, cfg, src_lang, tgt_lang, channels=3):
        super(Network, self).__init__()
        
        self.cfg = cfg

        # img patch with CNN projection
        image_height = image_width = cfg.diagram_size 
        patch_height = patch_width = cfg.img_patch_size
        assert  image_height % patch_height ==0 and image_width % patch_width == 0
        self.num_patches = (image_height // patch_height) * (image_width // patch_width)
        self.visual_extractor = get_visual_backbone(cfg)
        self.visual_emb_unify = nn.Linear(self.visual_extractor.final_feat_dim[0], cfg.encoder_embedding_size)
        
        self.dropout = nn.Dropout(self.cfg.project_dropout)
        self.transformer_en = TransformerEncoder(self.num_patches, d_model=cfg.encoder_embedding_size, nhead=cfg.pretrain_head, num_encoder_layers=cfg.pretrain_layer, dim_feedforward=4*cfg.encoder_embedding_size)
        
        # embedding for text
        self.text_embedding_src = self.get_text_embedding_src(
            vocab_size = src_lang.n_words,
            embedding_dim = cfg.encoder_embedding_size,
            padding_idx = 0,
            pretrain_emb_path = cfg.pretrain_emb_path
        )
        self.class_tag_embedding = nn.Embedding(
            len(src_lang.class_tag), 
            cfg.encoder_embedding_size, 
            padding_idx=0
        )
        self.sect_tag_embedding = nn.Embedding(
            len(src_lang.sect_tag), 
            cfg.encoder_embedding_size, 
            padding_idx=0
        )
        # Head for MLM
        self.head_for_mlm = nn.Linear(cfg.encoder_hidden_size, src_lang.n_words)
        # Head for point_img_match
        self.head_for_img  = nn.Linear(cfg.encoder_hidden_size, cfg.encoder_hidden_size)
        self.head_for_text  = nn.Linear(cfg.encoder_hidden_size, cfg.encoder_hidden_size)
        
    def forward(self, diagram_src, text_dict, is_train=True):
        '''
            diagram_src: B x C x W x H
            text_dict = {'token', 'sect_tag', 'class_tag', 'len', 'labels'}
        '''
        img_emb = self.visual_extractor(diagram_src) # B x dim x pn x pn
        img_emb = img_emb.view(img_emb.shape[0], img_emb.shape[1], -1).transpose(1,2)  # B x (pnxpn) dim
        img_emb = self.visual_emb_unify(img_emb)
            
        img_emb = self.dropout(img_emb)
        
        token_emb = self.text_embedding_src(text_dict['token'])
        class_tag_emb = self.class_tag_embedding(text_dict['class_tag'])
        sect_tag_emb = self.sect_tag_embedding(text_dict['sect_tag'])
        text_emb_src = token_emb.sum(dim=1) + sect_tag_emb + class_tag_emb
        
        transformer_outputs = self.transformer_en(img_emb, text_emb_src, self.num_patches, text_dict['len'])
        
        img_outputs = transformer_outputs[:,:self.num_patches,:]
        text_outputs = transformer_outputs[:,self.num_patches:,:]
        
        mlm_score = self.head_for_mlm(text_outputs)
        
        img_feat = self.head_for_img(img_outputs)
        img_feat_norm = img_feat / torch.norm(img_feat, dim=-1, keepdim=True)
        text_feat = self.head_for_text(text_outputs)
        text_feat_norm = text_feat / torch.norm(text_feat, dim=-1, keepdim=True)
        sim_score = torch.bmm(text_feat_norm, img_feat_norm.transpose(1,2))
        return mlm_score, sim_score

    def freeze_module(self, module):
        self.cfg.logger.info("Freezing module of "+" .......")
        for p in module.parameters():
            p.requires_grad = False

    def load_model(self, model_path):
        pretrain_dict = torch.load(
            model_path, map_location="cuda"
        )
        pretrain_dict_model = pretrain_dict['state_dict'] if 'state_dict' in pretrain_dict else pretrain_dict
        model_dict = self.state_dict()
        from collections import OrderedDict
        new_dict = OrderedDict()
        for k, v in pretrain_dict_model.items():
            if k.startswith("module"):
                new_dict[k[7:]] = v
            else:
                new_dict[k] = v
        model_dict.update(new_dict)
        self.load_state_dict(model_dict)
        return pretrain_dict
    
    def get_text_embedding_src(self, vocab_size, embedding_dim, padding_idx, pretrain_emb_path):
        embedding_src = nn.Embedding(vocab_size, embedding_dim, padding_idx=padding_idx)
        if pretrain_emb_path!='':
            emb_content = []
            with open(pretrain_emb_path, 'r') as f:
                for line in f:
                    emb_content.append(line.split()[1:])
                vector = np.asarray(emb_content, "float32") 
            embedding_src.weight.data[-len(emb_content):].copy_(torch.from_numpy(vector))
        return embedding_src
    
def get_model(args, src_lang, tgt_lang):
    model = Network(args, src_lang, tgt_lang)
    args.logger.info(str(model))
    return model





    
